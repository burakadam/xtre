const forecastData = []
export default { forecastData }
