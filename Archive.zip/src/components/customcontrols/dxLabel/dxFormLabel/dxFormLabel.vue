<template>
      <label >{{value}}</label>
</template>

<script>
export default {
  name: 'dxFormLabel',
  props: {
    value: String
  }
}
</script>
