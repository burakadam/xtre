const iData = [
  {
    InvoiceNumber: 'DE023844400000000161',
    InvoiceDate: '29.06.2021',
    Amount: '17.800',
    AmountWithTax: '21.400',
    InvoiceTaxCurrency: '1.18',
    Currency: '8.9',
    PossibleActualPaymentDate: '17.08.2021',
    ActualPaymentDate: '',
    Status: 'waiting',
    PaymentType: '',
    AdvancedPaymentInvoiceId: ''
  },
  {
    InvoiceNumber: 'DE023844400000000161',
    InvoiceDate: '29.06.2021',
    Amount: '17.800',
    AmountWithTax: '21.400',
    InvoiceTaxCurrency: '1.18',
    Currency: '8.9',
    PossibleActualPaymentDate: '17.08.2021',
    ActualPaymentDate: '',
    Status: 'waiting',
    PaymentType: '',
    AdvancedPaymentInvoiceId: ''
  },
  {
    InvoiceNumber: 'DE023844400000000161',
    InvoiceDate: '29.06.2021',
    Amount: '17.800',
    AmountWithTax: '21.400',
    InvoiceTaxCurrency: '1.18',
    Currency: '8.9',
    PossibleActualPaymentDate: '17.08.2021',
    ActualPaymentDate: '20.08.2021',
    Status: 'paid',
    PaymentType: '',
    AdvancedPaymentInvoiceId: ''
  },
  {
    InvoiceNumber: 'DE023844400000000161',
    InvoiceDate: '29.06.2021',
    Amount: '17.800',
    AmountWithTax: '21.400',
    InvoiceTaxCurrency: '1.18',
    Currency: '8.9',
    PossibleActualPaymentDate: '17.08.2021',
    ActualPaymentDate: '20.08.2021',
    Status: 'paid',
    PaymentType: '',
    AdvancedPaymentInvoiceId: ''
  },
  {
    InvoiceNumber: 'DE023844400000000161',
    InvoiceDate: '29.06.2021',
    Amount: '17.800',
    AmountWithTax: '21.400',
    InvoiceTaxCurrency: '1.18',
    Currency: '8.9',
    PossibleActualPaymentDate: '17.08.2021',
    ActualPaymentDate: '20.08.2021',
    Status: 'paid',
    PaymentType: '',
    AdvancedPaymentInvoiceId: ''
  },
  {
    InvoiceNumber: 'DE023844400000000161',
    InvoiceDate: '29.06.2021',
    Amount: '17.800',
    AmountWithTax: '21.400',
    InvoiceTaxCurrency: '1.18',
    Currency: '8.9',
    PossibleActualPaymentDate: '17.08.2021',
    ActualPaymentDate: '20.08.2021',
    Status: 'paid',
    PaymentType: '',
    AdvancedPaymentInvoiceId: ''
  }
]

export default iData
