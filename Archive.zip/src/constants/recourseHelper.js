const rData = [
  {
    people: 'Murat Kaya',
    level: '-',
    lcr: '7.800',
    jun: '0.00',
    jul: '0.00',
    aug: '0.00',
    sep: '0.00',
    oct: '0.00',
    nov: '0.00',
    dec: '0.00',
    jan: '100.000',
    feb: '0.00',
    apr: '100.000',
    may: '0.00'
  },
  {
    people: 'Hakan Özcan',
    level: 'DL',
    lcr: '7.800',
    jun: '0.00',
    jul: '0.00',
    aug: '0.00',
    sep: '0.00',
    oct: '0.00',
    nov: '0.00',
    dec: '0.00',
    jan: '100.000',
    feb: '0.00',
    apr: '100.000',
    may: '0.00'
  },
  {
    people: 'Murat Kaya',
    level: '-',
    lcr: '7.800',
    jun: '0.00',
    jul: '0.00',
    aug: '0.00',
    sep: '0.00',
    oct: '0.00',
    nov: '0.00',
    dec: '0.00',
    jan: '100.000',
    feb: '0.00',
    apr: '100.000',
    may: '0.00'
  }
]

export default rData
