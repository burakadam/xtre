const nData = [
  {
    customer: 'NTS - ABC',
    project: 'NTSPR2021FIGO - Financial Governance',
    forecast: 'A1 - Master',
    related_person: 'Murat Kaya',
    date: '17.08.2021',
    info: 'waiting for the payment'
  },
  {
    customer: 'NTS - ABC',
    project: 'NTSPR2021FIGO - Financial Governance',
    forecast: 'A1 - Master',
    related_person: 'Murat Kaya',
    date: '17.08.2021',
    info: 'waiting for the payment'
  },
  {
    customer: 'NTS - ABC',
    project: 'NTSPR2021FIGO - Financial Governance',
    forecast: 'A1 - Master',
    related_person: 'Murat Kaya',
    date: '17.08.2021',
    info: 'waiting for the payment'
  },
  {
    customer: 'NTS - ABC',
    project: 'NTSPR2021FIGO - Financial Governance',
    forecast: 'A1 - Master',
    related_person: 'Murat Kaya',
    date: '17.08.2021',
    info: 'paid'
  },
  {
    customer: 'NTS - ABC',
    project: 'NTSPR2021FIGO - Financial Governance',
    forecast: 'A1 - Master',
    related_person: 'Murat Kaya',
    date: '17.08.2021',
    info: 'waiting for the payment'
  },
  {
    customer: 'NTS - ABC',
    project: 'NTSPR2021FIGO - Financial Governance',
    forecast: 'A1 - Master',
    related_person: 'Murat Kaya',
    date: '17.08.2021',
    info: 'waiting for the payment'
  },
  {
    customer: 'NTS - ABC',
    project: 'NTSPR2021FIGO - Financial Governance',
    forecast: 'A1 - Master',
    related_person: 'Murat Kaya',
    date: '17.08.2021',
    info: 'waiting for the payment'
  },
  {
    customer: 'NTS - ABC',
    project: 'NTSPR2021FIGO - Financial Governance',
    forecast: 'A1 - Master',
    related_person: 'Murat Kaya',
    date: '17.08.2021',
    info: 'waiting for the payment'
  },
  {
    customer: 'NTS - ABC',
    project: 'NTSPR2021FIGO - Financial Governance',
    forecast: 'A1 - Master',
    related_person: 'Murat Kaya',
    date: '17.08.2021',
    info: 'paid'
  },
  {
    customer: 'NTS - ABC',
    project: 'NTSPR2021FIGO - Financial Governance',
    forecast: 'A1 - Master',
    related_person: 'Murat Kaya',
    date: '17.08.2021',
    info: 'waiting for the payment'
  },
  {
    customer: 'NTS - ABC',
    project: 'NTSPR2021FIGO - Financial Governance',
    forecast: 'A1 - Master',
    related_person: 'Murat Kaya',
    date: '17.08.2021',
    info: 'waiting for the payment'
  },
  {
    customer: 'NTS - ABC',
    project: 'NTSPR2021FIGO - Financial Governance',
    forecast: 'A1 - Master',
    related_person: 'Murat Kaya',
    date: '17.08.2021',
    info: 'waiting for the payment'
  },
  {
    customer: 'NTS - ABC',
    project: 'NTSPR2021FIGO - Financial Governance',
    forecast: 'A1 - Master',
    related_person: 'Murat Kaya',
    date: '17.08.2021',
    info: 'waiting for the payment'
  },
  {
    customer: 'NTS - ABC',
    project: 'NTSPR2021FIGO - Financial Governance',
    forecast: 'A1 - Master',
    related_person: 'Murat Kaya',
    date: '17.08.2021',
    info: 'paid'
  },
  {
    customer: 'NTS - ABC',
    project: 'NTSPR2021FIGO - Financial Governance',
    forecast: 'A1 - Master',
    related_person: 'Murat Kaya',
    date: '17.08.2021',
    info: 'waiting for the payment'
  },
  {
    customer: 'NTS - ABC',
    project: 'NTSPR2021FIGO - Financial Governance',
    forecast: 'A1 - Master',
    related_person: 'Murat Kaya',
    date: '17.08.2021',
    info: 'waiting for the payment'
  },
  {
    customer: 'NTS - ABC',
    project: 'NTSPR2021FIGO - Financial Governance',
    forecast: 'A1 - Master',
    related_person: 'Murat Kaya',
    date: '17.08.2021',
    info: 'waiting for the payment'
  },
  {
    customer: 'NTS - ABC',
    project: 'NTSPR2021FIGO - Financial Governance',
    forecast: 'A1 - Master',
    related_person: 'Murat Kaya',
    date: '17.08.2021',
    info: 'waiting for the payment'
  },
  {
    customer: 'NTS - ABC',
    project: 'NTSPR2021FIGO - Financial Governance',
    forecast: 'A1 - Master',
    related_person: 'Murat Kaya',
    date: '17.08.2021',
    info: 'paid'
  },
  {
    customer: 'NTS - ABC',
    project: 'NTSPR2021FIGO - Financial Governance',
    forecast: 'A1 - Master',
    related_person: 'Murat Kaya',
    date: '17.08.2021',
    info: 'waiting for the payment'
  }
]

export default nData
