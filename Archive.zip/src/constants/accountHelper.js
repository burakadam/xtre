const aData = [
  {
    client: 'NTS - ABC',
    project: 'NTSPR2021FIASDASD',
    wbs: 'DE023844400000000161',
    invoiceNo: '23844400000000161',
    invoiceDate: '29.06.2021',
    amoutWithVat: '21.400',
    vatRate: '%18',
    estimatedPaymentDate: '17.08.2021',
    paymentDate: '17.08.2021',
    state: 'invoice waiting',
    currency: '8.9'
  },
  {
    client: 'NTS - ABC',
    project: 'NTSPR2021FIASDASD',
    wbs: 'DE023844400000000161',
    invoiceNo: '23844400000000161',
    invoiceDate: '29.06.2021',
    amoutWithVat: '21.400',
    vatRate: '%18',
    estimatedPaymentDate: '17.08.2021',
    paymentDate: '17.08.2021',
    state: 'payment waiting',
    currency: '8.9'
  },
  {
    client: 'NTS - ABC',
    project: 'NTSPR2021FIASDASD',
    wbs: 'DE023844400000000161',
    invoiceNo: '23844400000000161',
    invoiceDate: '29.06.2021',
    amoutWithVat: '21.400',
    vatRate: '%18',
    estimatedPaymentDate: '17.08.2021',
    paymentDate: '17.08.2021',
    state: 'payment waiting',
    currency: '8.9'
  }
]

export default aData
